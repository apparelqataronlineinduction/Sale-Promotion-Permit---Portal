# Permit Portal: setup (about 20 minutes, one time)

1. **Supabase**: create a project (free tier is fine). Authentication → Providers → Email on. Turn off "Allow new users to sign up" so only you can create logins.
2. **Database**: SQL Editor → paste `schema.sql` → Run.
3. **First admin**: Authentication → Add user (your email + password). Then run:
   `update profiles set role='ADMIN' where email='you@company.com';`
4. **Frontend**: in `index.html` set `SUPABASE_URL` and `SUPABASE_ANON_KEY` (Project Settings → API; the anon key is meant to be public, RLS protects the data). Deploy the single file to Netlify, Vercel, Cloudflare Pages or GitHub Pages. The URL is then permanent.
5. **Routine use**: log in → Upload Excel → Preview → Confirm. Nothing else changes.
6. **Users**: create each login in Supabase Authentication, then assign brands in the portal's Users & Brands page.

## Record matching
`tracker_type | TL No. | Commercial Registration No. | Branch` (same rule as your consolidated dashboard).
Match → update if any of brand name, mechanism, dates or status changed; no match → new record. Re-uploading the same file gives 0 new / 0 updated.
Consequence: a later offer on the same TL and branch **updates** that record; the earlier version is archived in `permit_history`.

## Tracker type
Your trackers have no EOSS/Special column, so you pick the type at upload (auto-guessed from the file name: "EOSS" → EOSS, otherwise Special Offer). All sheets in a workbook are imported.

## Security model
Browser can only SELECT, and only through RLS policies (`permit_records`: admin or brand assigned to the user). Uploads, user and brand changes only run through admin-checked functions. Run `tests.sql` after setup.
