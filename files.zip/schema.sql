-- Sale & Promotion Permit Portal: run once in Supabase SQL Editor.
-- All writes go through SECURITY DEFINER functions; clients get SELECT only, filtered by RLS.

create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  name text, email text,
  role text not null default 'BRAND_USER' check (role in ('ADMIN','BRAND_USER')),
  active boolean not null default true,
  created_at timestamptz default now(), last_login timestamptz);

create table public.brands (
  id uuid primary key default gen_random_uuid(),
  brand_name text unique not null, active boolean not null default true);

create table public.user_brand_access (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles on delete cascade,
  brand_id uuid not null references public.brands on delete cascade,
  access_level text not null default 'VIEW', created_at timestamptz default now(),
  unique (user_id, brand_id));

create table public.upload_history (
  id uuid primary key default gen_random_uuid(),
  file_name text, tracker_type text, uploaded_by uuid, uploaded_by_name text,
  upload_date timestamptz default now(),
  total_records int, new_records int, updated_records int, unchanged_records int,
  failed_records int default 0, status text);

-- tracker_type (EOSS / SPECIAL) plays the role of "program"/"mechanism_type"
create table public.permit_records (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.brands,
  brand text not null, brand_name text, branch_location text not null,
  trade_license text not null, commercial_registration text not null,
  tracker_type text not null check (tracker_type in ('EOSS','SPECIAL')),
  mechanism text, start_date date not null, end_date date not null,
  status text not null, remarks text,
  match_key text not null unique,
  last_upload_id uuid, created_at timestamptz default now(), updated_at timestamptz default now());
create index on public.permit_records (brand_id);

-- Versioning: prior version of every record is archived before an import changes it
create table public.permit_history (
  id uuid primary key default gen_random_uuid(),
  permit_id uuid, upload_id uuid, snapshot jsonb, archived_at timestamptz default now());

create table public.audit_log (
  id bigint generated always as identity primary key,
  user_id uuid, user_name text, action text, detail text, created_at timestamptz default now());

-- ---------- helpers ----------
create function public.is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'ADMIN' and active) $$;

create function public.my_brand_ids() returns setof uuid language sql stable security definer set search_path = public as
$$ select uba.brand_id from user_brand_access uba
   join profiles p on p.id = uba.user_id join brands b on b.id = uba.brand_id
   where uba.user_id = auth.uid() and p.active and b.active $$;

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as
$$ begin
  insert into profiles (id, email, name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)));
  return new; end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- row-level security ----------
alter table profiles enable row level security;
alter table brands enable row level security;
alter table user_brand_access enable row level security;
alter table permit_records enable row level security;
alter table upload_history enable row level security;
alter table permit_history enable row level security;
alter table audit_log enable row level security;

create policy p_profiles on profiles for select to authenticated using (id = auth.uid() or is_admin());
create policy p_brands on brands for select to authenticated using (is_admin() or id in (select my_brand_ids()));
create policy p_uba on user_brand_access for select to authenticated using (user_id = auth.uid() or is_admin());
create policy p_permits on permit_records for select to authenticated
  using (is_admin() or brand_id in (select my_brand_ids()));
create policy p_uploads on upload_history for select to authenticated using (is_admin());
create policy p_phist on permit_history for select to authenticated using (is_admin());
create policy p_audit on audit_log for select to authenticated using (is_admin());

revoke all on all tables in schema public from anon, authenticated;
grant select on profiles, brands, user_brand_access, permit_records, upload_history, permit_history, audit_log to authenticated;
-- no INSERT/UPDATE/DELETE policies or grants: the browser cannot write anything directly.

-- ---------- audit + status ----------
create function public.log_action(p_action text, p_detail text default null) returns void
language plpgsql security definer set search_path = public as
$$ begin
  if auth.uid() is null then return; end if;
  if p_action not in ('LOGIN','LOGOUT') then raise exception 'Not allowed'; end if;
  insert into audit_log (user_id, user_name, action, detail)
    select id, name, p_action, p_detail from profiles where id = auth.uid();
  if p_action = 'LOGIN' then update profiles set last_login = now() where id = auth.uid(); end if;
end $$;

create function public.last_update() returns jsonb language sql stable security definer set search_path = public as
$$ select coalesce((select jsonb_build_object('upload_date', upload_date, 'uploaded_by', uploaded_by_name)
   from upload_history where status = 'Successful' order by upload_date desc limit 1), '{}'::jsonb)
   where auth.uid() is not null $$;

-- ---------- Excel import (admin only) ----------
-- p_rows: [{brand, brand_name, branch, tl, cr, mechanism, start:'YYYY-MM-DD', end:'YYYY-MM-DD', status}]
-- MATCHING KEY: tracker_type | TL No. | Commercial Reg. No. | Branch  (same rule as the consolidated dashboard)
-- Match found -> UPDATE (only if something changed); no match -> INSERT. Dates/status/mechanism are NOT in the key,
-- so a permit moving "on process" -> "permit received" or getting extended updates the same record.
create function public.import_run(p_rows jsonb, p_type text, p_file text, p_commit boolean default false)
returns jsonb language plpgsql security definer set search_path = public as
$$
declare v_total int; v_bad int; v_new int; v_upd int; v_same int; v_clean int; v_up uuid; v_name text; v_errs jsonb;
begin
  if not is_admin() then raise exception 'Admin only'; end if;
  if p_type not in ('EOSS','SPECIAL') then raise exception 'Invalid tracker type'; end if;
  drop table if exists _raw; drop table if exists _err; drop table if exists _clean;

  create temp table _raw on commit drop as
  select ord::int ord, upper(btrim(r->>'brand')) brand, nullif(btrim(r->>'brand_name'),'') brand_name,
         upper(btrim(r->>'branch')) branch, btrim(r->>'tl') tl, btrim(r->>'cr') cr,
         nullif(btrim(r->>'mechanism'),'') mech, r->>'start' sd, r->>'end' ed, lower(btrim(r->>'status')) status
  from jsonb_array_elements(p_rows) with ordinality t(r, ord);
  select count(*) into v_total from _raw;
  if v_total = 0 then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(jsonb_build_object('row', null, 'message', 'File contains no data rows')), 'failed', 0, 'total', 0);
  end if;

  create temp table _err on commit drop as
  select ord, msg from (
    select ord, 'Missing Brand' msg from _raw where coalesce(brand,'') = ''
    union all select ord, 'Missing Branch Location' from _raw where coalesce(branch,'') = ''
    union all select ord, 'Missing TL No.' from _raw where coalesce(tl,'') = ''
    union all select ord, 'Missing Commercial Registration No.' from _raw where coalesce(cr,'') = ''
    union all select ord, 'Invalid Start date' from _raw where sd is null or sd !~ '^\d{4}-\d{2}-\d{2}$'
    union all select ord, 'Invalid End date' from _raw where ed is null or ed !~ '^\d{4}-\d{2}-\d{2}$'
    union all select ord, 'Invalid status "' || coalesce(status,'') || '"' from _raw
      where status is null or not (status in ('permit received','on process') or status like 'waiting approval%')
    union all select ord, 'End date is before Start date' from _raw
      where sd ~ '^\d{4}-\d{2}-\d{2}$' and ed ~ '^\d{4}-\d{2}-\d{2}$' and ed::date < sd::date
  ) e;
  select count(distinct ord) into v_bad from _err;
  if v_bad > 0 then
    select jsonb_agg(jsonb_build_object('row', ord + 1, 'message', msg) order by ord) into v_errs
      from (select * from _err order by ord limit 50) x;
    return jsonb_build_object('ok', false, 'failed', v_bad, 'total', v_total, 'errors', v_errs);
  end if;

  create temp table _clean on commit drop as
  select distinct on (mk) * from
    (select *, p_type || '|' || tl || '|' || upper(cr) || '|' || branch as mk from _raw) x
  order by mk, ord desc;   -- duplicates inside the file: last row wins
  select count(*) into v_clean from _clean;

  select count(*) filter (where pr.id is null),
         count(*) filter (where pr.id is not null and (pr.brand, pr.brand_name, pr.mechanism, pr.start_date, pr.end_date, pr.status)
            is distinct from (c.brand, coalesce(c.brand_name, c.brand), c.mech, c.sd::date, c.ed::date, c.status)),
         count(*) filter (where pr.id is not null and (pr.brand, pr.brand_name, pr.mechanism, pr.start_date, pr.end_date, pr.status)
            is not distinct from (c.brand, coalesce(c.brand_name, c.brand), c.mech, c.sd::date, c.ed::date, c.status))
    into v_new, v_upd, v_same
  from _clean c left join permit_records pr on pr.match_key = c.mk;

  if not p_commit then
    return jsonb_build_object('ok', true, 'total', v_total, 'new', v_new, 'updated', v_upd,
                              'unchanged', v_same, 'duplicates_in_file', v_total - v_clean, 'invalid', 0);
  end if;

  select name into v_name from profiles where id = auth.uid();
  insert into upload_history (file_name, tracker_type, uploaded_by, uploaded_by_name, total_records, new_records,
                              updated_records, unchanged_records, failed_records, status)
    values (p_file, p_type, auth.uid(), v_name, v_total, v_new, v_upd, v_same, 0, 'Successful') returning id into v_up;

  insert into brands (brand_name) select distinct brand from _clean on conflict (brand_name) do nothing;

  insert into permit_history (permit_id, upload_id, snapshot)
  select pr.id, v_up, to_jsonb(pr) from permit_records pr join _clean c on c.mk = pr.match_key
  where (pr.brand, pr.brand_name, pr.mechanism, pr.start_date, pr.end_date, pr.status)
        is distinct from (c.brand, coalesce(c.brand_name, c.brand), c.mech, c.sd::date, c.ed::date, c.status);

  insert into permit_records (brand_id, brand, brand_name, branch_location, trade_license, commercial_registration,
                              tracker_type, mechanism, start_date, end_date, status, match_key, last_upload_id)
  select b.id, c.brand, coalesce(c.brand_name, c.brand), c.branch, c.tl, c.cr, p_type, c.mech,
         c.sd::date, c.ed::date, c.status, c.mk, v_up
  from _clean c join brands b on b.brand_name = c.brand
  on conflict (match_key) do update set
    brand_id = excluded.brand_id, brand = excluded.brand, brand_name = excluded.brand_name,
    mechanism = excluded.mechanism, start_date = excluded.start_date, end_date = excluded.end_date,
    status = excluded.status, last_upload_id = v_up, updated_at = now()
  where (permit_records.brand, permit_records.brand_name, permit_records.mechanism, permit_records.start_date,
         permit_records.end_date, permit_records.status)
        is distinct from (excluded.brand, excluded.brand_name, excluded.mechanism, excluded.start_date,
                          excluded.end_date, excluded.status);

  insert into audit_log (user_id, user_name, action, detail)
    values (auth.uid(), v_name, 'EXCEL_IMPORT', p_file || ': ' || v_total || ' rows, ' || v_new || ' new, ' || v_upd || ' updated');
  return jsonb_build_object('ok', true, 'upload_id', v_up, 'total', v_total, 'new', v_new, 'updated', v_upd,
                            'unchanged', v_same, 'uploaded_by', v_name, 'upload_date', now());
exception when others then
  return jsonb_build_object('ok', false, 'failed', 0, 'total', coalesce(v_total, 0),
    'errors', jsonb_build_array(jsonb_build_object('row', null, 'message', sqlerrm)));
end $$;

-- ---------- admin management ----------
create function public.admin_save_user(p_user uuid, p_role text, p_active boolean, p_brands uuid[])
returns void language plpgsql security definer set search_path = public as
$$ declare v_admin text;
begin
  if not is_admin() then raise exception 'Admin only'; end if;
  if p_user = auth.uid() and (p_role <> 'ADMIN' or not p_active) then raise exception 'You cannot demote or deactivate yourself'; end if;
  update profiles set role = p_role, active = p_active where id = p_user;
  delete from user_brand_access where user_id = p_user and not (brand_id = any (coalesce(p_brands, '{}')));
  insert into user_brand_access (user_id, brand_id) select p_user, unnest(coalesce(p_brands, '{}')) on conflict do nothing;
  select name into v_admin from profiles where id = auth.uid();
  insert into audit_log (user_id, user_name, action, detail)
    values (auth.uid(), v_admin, 'USER_ACCESS_SAVED',
            (select email from profiles where id = p_user) || ' role=' || p_role || ' active=' || p_active
            || ' brands=' || coalesce(array_length(p_brands, 1), 0));
end $$;

create function public.admin_add_brand(p_name text) returns void language plpgsql security definer set search_path = public as
$$ begin
  if not is_admin() then raise exception 'Admin only'; end if;
  insert into brands (brand_name) values (upper(btrim(p_name))) on conflict do nothing;
  insert into audit_log (user_id, user_name, action, detail)
    select id, name, 'BRAND_ADDED', upper(btrim(p_name)) from profiles where id = auth.uid();
end $$;

create function public.admin_set_brand_active(p_brand uuid, p_active boolean) returns void
language plpgsql security definer set search_path = public as
$$ begin
  if not is_admin() then raise exception 'Admin only'; end if;
  update brands set active = p_active where id = p_brand;   -- permit records are never deleted
  insert into audit_log (user_id, user_name, action, detail)
    select id, name, 'BRAND_ACTIVE_' || p_active, p_brand::text from profiles where id = auth.uid();
end $$;

revoke execute on all functions in schema public from public, anon;
grant execute on function is_admin(), my_brand_ids(), log_action(text, text), last_update(),
  import_run(jsonb, text, text, boolean), admin_save_user(uuid, text, boolean, uuid[]),
  admin_add_brand(text), admin_set_brand_active(uuid, boolean) to authenticated;
