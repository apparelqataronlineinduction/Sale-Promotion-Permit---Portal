-- Run in Supabase SQL Editor AFTER importing data and assigning brands.
-- Replace the UUIDs (Authentication → Users). Each block ends with ROLLBACK, so nothing is changed.

-- Test 1/2/3/5: brand user sees only assigned brands, even when asking for another brand directly
begin;
set local role authenticated;
select set_config('request.jwt.claims', json_build_object('sub','<USER_A_UUID>','role','authenticated')::text, true);
select brand, count(*) from permit_records group by brand;           -- expect only User A's brand(s)
select count(*) from permit_records where brand = 'DUNE';            -- expect 0 if A has no Dune access
select count(*) from permit_records where id = '<A_DUNE_PERMIT_ID>'; -- expect 0
rollback;

-- Test 4 (export uses the same SELECT) is covered by the above.

-- Test 7: brand user cannot write or upload
begin;
set local role authenticated;
select set_config('request.jwt.claims', json_build_object('sub','<USER_A_UUID>','role','authenticated')::text, true);
delete from permit_records;                                           -- expect: permission denied
rollback;
begin;
set local role authenticated;
select set_config('request.jwt.claims', json_build_object('sub','<USER_A_UUID>','role','authenticated')::text, true);
select import_run('[]'::jsonb, 'EOSS', 'x.xlsx', true);               -- expect: Admin only
rollback;

-- Test 6: remove a brand → immediately inaccessible (re-run Test 1 after saving in Users & Brands)

-- Admin sees everything
begin;
set local role authenticated;
select set_config('request.jwt.claims', json_build_object('sub','<ADMIN_UUID>','role','authenticated')::text, true);
select count(*) from permit_records;
rollback;
